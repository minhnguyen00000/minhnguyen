-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th12 09, 2020 lúc 04:01 CH
-- Phiên bản máy phục vụ: 5.7.14
-- Phiên bản PHP: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `sangperfume`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `binhluan`
--

CREATE TABLE `binhluan` (
  `idbinhluan` int(11) NOT NULL,
  `idsanpham` int(11) NOT NULL,
  `hoten` varchar(255) NOT NULL,
  `ngaygio` datetime NOT NULL,
  `noidung` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `danhmuc`
--

CREATE TABLE `danhmuc` (
  `iddanhmuc` int(11) NOT NULL,
  `tendanhmuc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `danhmuc`
--

INSERT INTO `danhmuc` (`iddanhmuc`, `tendanhmuc`) VALUES
(1, 'Nước hoa Nam'),
(2, 'Nước hoa Nữ'),
(3, 'Nước hoa Unisex');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `giohang`
--

CREATE TABLE `giohang` (
  `idgiohang` int(11) NOT NULL,
  `idhoadon` int(11) NOT NULL,
  `dongia` int(11) NOT NULL,
  `soluongmua` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoadon`
--

CREATE TABLE `hoadon` (
  `idhoadon` int(11) NOT NULL,
  `idkhachhang` int(11) NOT NULL,
  `idtinhtrang` int(11) NOT NULL,
  `ngaylaphoadon` datetime NOT NULL,
  `tonggia` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `hoadon`
--

INSERT INTO `hoadon` (`idhoadon`, `idkhachhang`, `idtinhtrang`, `ngaylaphoadon`, `tonggia`) VALUES
(56, 3, 1, '2020-12-09 22:57:21', 15000000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khachhang`
--

CREATE TABLE `khachhang` (
  `idkhachhang` int(11) NOT NULL,
  `tenkhachhang` varchar(255) NOT NULL,
  `sdt` varchar(25) NOT NULL,
  `mail` varchar(255) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `taikhoan` varchar(255) NOT NULL,
  `matkhau` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `khachhang`
--

INSERT INTO `khachhang` (`idkhachhang`, `tenkhachhang`, `sdt`, `mail`, `diachi`, `taikhoan`, `matkhau`) VALUES
(3, 'Dương Ngọc Sang', '0902637442', 'dnsang007@gmail.com', '510 Kinh Dương Vương, An Lạc, Bình Tân', 'dnsang007', '123456'),
(4, 'Khách Hàng A', '0909000999', 'khachhanga123@gmail.com', 'Bình Tân', 'khachhanga', '123456'),
(5, 'admin', '0901202101', 'admin@sangperfume.com', 'Bình Tân', 'admin', '1');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `idsanpham` int(11) NOT NULL,
  `idhoadon` int(11) DEFAULT NULL,
  `iddanhmuc` int(11) NOT NULL,
  `idkhuyenmai` int(11) DEFAULT NULL,
  `tensanpham` varchar(255) NOT NULL,
  `anhsanpham` varchar(255) NOT NULL,
  `giasanpham` int(11) DEFAULT NULL,
  `giakhuyenmai` int(11) DEFAULT NULL,
  `thuonghieu` varchar(255) NOT NULL,
  `motasanpham` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`idsanpham`, `idhoadon`, `iddanhmuc`, `idkhuyenmai`, `tensanpham`, `anhsanpham`, `giasanpham`, `giakhuyenmai`, `thuonghieu`, `motasanpham`) VALUES
(1, NULL, 1, 1, 'Dunhill London Desire Men', 'Dunhill-London-Desire-1.jpg', 1450000, 880000, 'Dunhill', 'Desire Blue là một hương thơm độc nhất trong thế giới nước hoa mang hương biển và quả vải chứa tinh chất trái cây và nữ tính. Thời gian lưu hương trong khoảng 5 – 7 tiếng và độ tỏa hương tương đối. Sử dụng tốt nhất trong mùa xuân và hè.\r\nNước hoa Desire của thương hiệu Alfred Dunhill thuộc dòng nước hoa Cây Cỏ Thơm dành cho phái nam. Desire đã được giới thiệu vào năm 2002 và Philippe Romano chính là người thiết kế nên sản phẩm này.\r\nTừ những giây phút đầu tiên, khứu giác của bạn sẽ được kích thích bởi những nốt hương trái cây liên hoàn, năng động và rực rỡ, mặt khác, hương thơm có mùi thơm của biển khơi với cảm xúc dễ chịu. Hương giữa của Desire Blue là bao gồm các nốt hương biển đi kèm với mùi thơm nền từ gỗ rừng. Hương trái vải rất dễ nhận ra xuyên suốt thời gian tỏa hương. Nước hoa dần khô, hương thơm rất mượt và quyến rũ với đậu tonka ngọt ngào và an tức hương ấm áp và êm thấm, tất cả cùng cân bằng với sự phong phú của hổ phách và xạ hương sáng trong.\r\nThiết kế dáng chai theo phong cách nam tính mạnh mẽ, góc canh, với nắp đậy độc đáo, đường nét dứt khoát tạo, kết hợp cùng chất liệu thủy tinh trong suốt thấy được màu nước hoa xanh biển bên trong tạo nên một tổng thể thu hút và sang trọng.'),
(2, NULL, 2, 1, '212 CH Good Girl Glorious Gold', 'P_212_CH_Good_Girl_Glorious_Gold.jpg', 3600000, 3450000, '212 Carolina Herrera', 'Good Girl Glorious Gold Collector Edition là phiên bản mới nhất trong bộ sưu tập những đôi guốc kiêu kỳ của nhà Carolina Herrera dành cho phái nữ. Được ra mắt vào năm 2019 bởi chuyên gia nước hoa Louise Turner và là phiên bản giới hạn, thế nên chẳng khó hiểu khi Good Girl Glorious Gold được các cô nàng săn lùng một cách quyết liệt như thế. Được phủ một lớp kim tuyến màu vàng phía ngoài thân chai, Good Girl Glorious Gold Collector Edition được định hình cho những bữa tiệc xa hoa, những party của giới thượng lưu, và dành cho những cô nàng muốn trở thành tâm điểm của buổi tiệc đó. Việc để Cacao và kẹo nhân hạt làm note hương chính cùng với Cacao và Đậu tonka làm vệ tinh, Đôi guốc vàng gây ấn tượng mạnh với sự ngọt ngào theo trường phái gần gũi, ấm áp. Nhưng khi các note hương yên vị trên da, Base note biến cô nàng thành một rừng hoa đúng nghĩa, bao vây đôi phương với sự ngọt ngào đầy rung cảm của Hoa hồng, Hoa huệ, nữ tính một cách dịu dàng với Hoa cam va Hoà nhài, trước khi lắng đọng vào suy nghĩ kẻ đối diện với những lời thì thì thầm ngọt ngào ma thuật của Vani và Hoa diên vỹ. Good Girl Glorious Gold Collector Edition là đôi guốc vàng trong làng thả thính, nếu bạn chưa tin, hãy thử một lần để xác thực điều đó nhé.'),
(3, NULL, 1, 1, 'Paco Rabanne Pure Xs Night Pure Xs Night', 'Paco_Rabanne_Pure_Xs_Night.jpg', 2250000, 2250000, 'Paco Rabanne', 'Pure Xs Night là một hương thơm mãnh liệt dành cho nam giới của Paco Rabanne. Hương thơm này mang công thức độc quyền khiến đối phương ham muốn dâng cao đầy mê hoặc. Sự trầm ngâm, ngập ngừng, bâng khuâng, ngại ngùng, e thẹn sẽ không thể cưỡng lại hương thơm quyến rũ và gợi cảm từ Pure Xs Night. Hương thơm khiêu khích sự tò mò ham muốn khám phá mãnh liệt.\r\n\r\nPure Xs Night là một hương thơm phương đông khiêu gợi mãnh liệt với các thành phần Nhân sâm và gừng, caramel mặn cay., hơi ấm của quế, cacao, vani, nhựa thơm Mộc dược (Myrrh).'),
(4, NULL, 1, 1, '212 Vip Black Own The Party Extra Men', '212_Vip_Black_Own_The_Party_Extra_Men.png', 2050000, NULL, '212 Carolina Herrera', '212 Vip Black Own The Party Extra Men được ra mắt 2020 với làm mới lại công thức cho ra hương thơm mãnh liệt và mạnh mẽ từ bản gốc 212 Vip Black để sử dụng trong các bữa tiệc cuồng nhiệt. Thành phần mới trong sản phẩm này là hương vị của rượu Rum cùng Cola, kết hợp với cam quýt và các thành phần công thức cũ như da thuộc, rêu, cacao, hoa Lavender, xạ hương, vani đen gợi cảm cho ra mùi hương nồng nàn gợi cảm của phái mạnh.'),
(5, NULL, 1, 1, 'Yes I Am The King Le Parfum', 'Yes_I_Am_The_King_Le_Parfum.png', 1450000, NULL, 'Geparlys', 'Đây là chai nước hoa nam đang thu hút giới trẻ hiện nay, với mùi hương sang trọng lịch lãm với giá cả cực kỳ cạnh tranh. Nhiều người sành nước hoa cho rằng nó có mùi hương tương tự như những chai nước hoa nam Chanel sang chảnh đắt tiền. Sau khi được giới thiệu ra công chúng, chai nước hoa nam này được săn đón, có lẽ đây chính là sự thành công nhất của hãng Geparlys – Yes I Am The King Le Parfum trong quá trình xây dựng thương hiệu của mình.\r\n\r\nNước hoa nam – Yes I Am The King Le Parfum đã được nhiều người đánh giá cao và luôn được bán chạy vì mùi hương không thể cưỡng lại với mức giá rất hấp dẫn dễ tiếp cận. Điều này không có gì là quá lạ lẫm bởi hương vị mạnh mẽ, nam tính đầy quyến rũ của chai nước hoa này đem lại khiến ai cũng muốn sở hữu và sử dụng nó thường xuyên mỗi ngày. Yes I Am The King Le Parfum là sản phẩm mang nhiều ưu điểm khiến bạn dù là trải nghiệm hay sở hữu được sản phẩm này thì vẫn là lựa chọn vô cùng tuyệt vời đối với cánh đàn ông muốn thể hiện đẳng cấp của mình.'),
(6, NULL, 1, 1, 'Louis Vuitton Meteore Eau de Parfum', 'Louis_Vuitton_Meteore_Eau_de_Parfum.png', 8950000, NULL, 'Louis Vuitton', 'Âm thanh xèo xèo của quả quýt cay nồng đánh thức mọi giác quan của bạn là những gì dùng để miêu tả về Louis Vuitton Meteore Eau de Parfum. Tên của nước hoa Météore hơi khó đọc vì đó không phải là danh từ, mà là tính từ mang ý nghĩa sức mạnh của ánh sáng. Hương thơm này khơi dậy sự mê hoặc khi thức dậy với một tinh thần tràn đầy năng lượng.\r\n\r\nĐể có được nguồn năng lượng trong hương thơm của Louis Vuitton Meteore Eau de Parfum. Người pha chế hương thơm này đã chọn quả quýt hồng Sicily từ nước Ý thơ mộng để có chất lượng tinh dầu quýt cực phẩm tốt nhất, cho ra hương thơm tuyệt vời được kết hợp cùng với 3 loại tiêu thượng hạng gồm tiêu đen, tiêu hồng của Ý và hạt tiêu Tứ Xuyên đến từ Châu Á huyền bí. Các nốt hương được nhấn nhá mạnh mẽ từ cỏ vetiver của vùng Java, đưa hương thơm lên tầm cao quý nhất. Một sự kết hợp giữa gia vị, trái cây, hoa cỏ tươi mới như sự hài hòa của đất trời làm mê hoặc đối phương không thể rời mắt. Louis Vuitton Meteore Eau de Parfum là nước hoa cao cấp thể hiện một vẻ đẹp sang trọng đương đại không giới hạn.'),
(7, NULL, 2, NULL, 'Kenzo Flower Tag', 'Kenzo_Flower_Tag.png', 640000, NULL, 'Kenzo', 'Kenzo Flower Tag là nước hoa nữ thuộc nhóm hương trái cây tươi mát. Nghệ thuật graffiti truyền cảm hứng cho Kenzo tạo nên loại nước hoa với nét độc đáo của riêng mình. Một hỗn hợp các hương trái cây như nho đen và quýt cùng hương thơm nữ tính của hoa mẫu đơn và hoa huệ vùng thung lũng, tạo ra một hương thơm trẻ trung nhưng vẫn tao nhã. Thiết kế chai màu đỏ và chữ graffiti đã mang đến truyền tải sự phấn khích và năng lượng của nghệ thuật đường phố.\r\n\r\nMùi Hương đặc trưng:\r\n\r\nHương đầu: Nho đen, đại hoàng, hoa mẫu đơn.\r\n\r\nHương giữa: Hoa lài, hoa lily, hương trà.\r\n\r\nHương cuối: Xạ hương trắng, Vani.'),
(8, NULL, 2, NULL, 'Mariah Carey M', 'Mariah_Carey_M.png', 1450000, NULL, '\r\nMariah Carey', 'Bạn không chỉ nên nghe giọng hát của Mariah Carey mà còn nên sử dụng mùi hương hoa của cô ấy. Hương thơm luôn thể hiện sự khao khát và suy nghĩ hơn là lời nói. M là dòng nước hoa có hương hoa cỏ thanh lịch dành cho phái đẹp.\r\nMở đầu của M không bình thương khi có sự kết hợp của kẹo dẻo Marshmallow ngọt ngào và cây dành dành. Hương hoa phương Đông lan tỏa rất mạnh mẽ nhưng khi kết hợp với hoắc hương, hổ phách và hương morocco ở lớp hương cuối thì lại trở nên dịu nhẹ.\r\nChai nước hoa mang hình ảnh tượng trung cho Mariah. Nắp chai thủy tinh thiết kế tinh tế có hình chú buoms vì nó dựa trên hình ảnh của hoa Tiare. Coorchai màu bạc được cách điệu tạo sự thanh lịch và mang nét tinh tế cho dòng nước hoa này. M thích hợp vào dùng ban ngày hoặc ban đêm vì hương xạ hương của nó nhẹ nhàng và vừa phải, có thể phù hợp khi dùng cả ở văng phòng hay di dạo trên phố đêm.'),
(9, NULL, 2, NULL, 'Chanel Coco Mademoiselle L’Eau Privée', 'Chanel_Coco_Mademoiselle.png', 4350000, NULL, 'Chanel', 'Chanel Coco Mademoiselle L’Eau Privée được ra mắt vào ngày 30 tháng 8 năm 2020 với công thức cải tiến được điều chỉnh từ công thức phiên bản trước đó của Chanel Coco Mademoiselle Intense. Mùi hương trong sản phẩm này đã giảm thành phần hương thơm của gỗ, tăng tỷ lệ cam quýt tươi và làm cho hương cam tươi sáng. Cùng với hương thơm nở rộ của các hương hoa mới được bổ sung thêm làm tăng sự dịu dàng như hoa hồng và hoa nhài, cùng xạ hương trắng thanh khiết, không quá nồng cũng không quá gắt, phù hợp sử dụng cho ngày dài và đêm.\r\nMở đầu với hương thơm của cam cam bergamot và quýt tươi sáng. Thoang thoảng chút hương hồng dại Phương Đông cùng hoắc hương mở lối cho cỏ vetiver, tonka và hương vani đậm đà dần hương thơm tầng cuối. Một số hương thơm bổ sung nhưng Chanel đã không nhắc đến là quả bưởi, vải thiều Việt Nam và hoa mimosa.\r\nChanel Coco Mademoiselle L’Eau Privée là một phiên bản nhẹ nhàng và tinh tế, mềm mại và gợi cảm, thanh tao nhưng tinh tế với hương thơm phương Đông dịu nhẹ. Chanel Coco Mademoiselle L’Eau Privée được tạo ra đặc biệt dành cho ban đêm và sử dụng hàng ngày (không phù hợp cho tiệc tùng), Chanel đã khuyến khích sử dụng hương thơm này thoa lên da, tóc hoặc váy ngủ trước khi đi ngủ. Hương thơm bao trùm khắp cơ thể và không gian xung quanh để đối phương đắm chìm trong sự quyến rũ độc đáo có 1-0-2 trong phiên bản Chanel Coco Mademoiselle L’Eau Privée này.'),
(10, NULL, 1, NULL, 'Paco Rabanne Invictus Onyx Collector Edition', 'Paco_Rabanne_Invictus_Onyx_Collector_Edition.png', 2250000, NULL, 'Paco Rabanne', 'Paco Rabanne Invictus Onyx Collector Edition của Paco Rabanne là một mùi hương mới dành cho nam giới được ra mắt vào năm 2020. Hương đầu là bưởi, hương biển và cam quýt; hương giữa là nguyệt quế và hoa nhài; Hương cuối là gỗ guaiac, rêu, hoắc hương và Long diên hương.\r\n\r\n'),
(11, NULL, 2, NULL, 'D&G Light Blue Women Love is Love', 'D&G_Light_Blue_Women_Love_is_Love.png', 1950000, NULL, 'Dolce & Gabbana', 'Mùa hè này, DOLCE & GABBANA Light Blue Love is Love mang đến mùi hương mang tính biểu tượng của chanh Ý và táo Granny Smith sắc nét thậm chí còn thú vị hơn với việc bổ sung các loại quả mọng đỏ. Một một chút gelato mâm xôi làm cho các nốt hương hoa nhài trở nên hấp dẫn hơn bao giờ hết, trong khi xạ hương kem và rượu mùi Chantilly mang lại cảm giác ngọt lành mới mẻ.\r\n\r\nHương đầu: Cam quýt, táo Granny Smith, quả mọng đỏ\r\nHương giữa: Mâm xôi, hoa nhài\r\nHương cuối: Xạ hương, Gỗ tuyết tùng, rượu mùi Chantilly'),
(12, NULL, 3, NULL, 'Bond No.9 Liberty Island', 'Bond_No.9_Liberty_Island.png', 4950000, NULL, 'Bond No 9', 'Chào mừng bạn đến với Đảo Tự Do. Đây là hương thơm dành cho mùa hè tốt nhất của hãng Bond No.9 được lấy cảm hứng từ hòn đảo nơi đặt tượng Nữ Thần Tự Do tại quê nhà, và tôn vinh các hòn đảo nổi tiếng nhất thế giới. Đồng thời ca ngợi sự tự do trên những vùng đất lãnh thổ đã gìn giữ bảo vệ sự tự do ấy.\r\n\r\nHương thơm của Bond No.9 Liberty Island là một sự pha trộn vui tươi, lấp lánh tràn ngập đầy hương hoa quyến rũ và trái cây chín mọng ngào ngạt. Hương thơm này dành cho cả nam và nữ yêu thích sự tự do mạnh mẽ.\r\n\r\nThành phần hương chính trong sản phẩm này là tinh chất đậm đặc của cam Bergamot nổi tiếng của California, mùi hương đặc trưng của các dòng nước hoa hương tươi mát, nhưng đặc biệt nó lại được pha trộn với loài cam Mandarin của Châu Á. Có lẽ nhà sáng chế hương thơm này vẫn chưa thỏa mãn sự tươi mát đến từ 2 loại cam kể trên, nên đã thêm vào hương thơm của Hoa Cam nguyên chất pha trộn với Hoa Nhài. Quả Lý chua đen thoang thoảng chín mọng và Xạ hương đã góp phần làm tăng sự quyến rũ vốn có của chai nước hoa này. Cuối cùng là át chủ bài của sản phẩm, một công thức bí mật từ kẹo dẻo Marshmallow làm nên sự ngọt ngào thần kỳ không giống với bất kỳ chai nước hoa nào mang hương thơm ngọt ngào đang có trên thị trường.'),
(13, NULL, 3, NULL, 'Mancera Roses Greedy Woman', 'Mancera_Roses Greedy_Woman.png', 2850000, NULL, 'Mancera', 'Roses Greedy của Mancera là một hương thơm Floral Fruity Gourmand dành cho phụ nữ và nam giới. Đây là dòng nước hoa Mancera thuộc nhóm Floral Fruity Gourmand (Hoa cỏ – Trái cây – Thực phẩm). Pierre Montale chính là nhà pha chế ra loại nước hoa này. Bên cạnh đó, Hoa hồng và Hương của hoa là hai hương bạn có thể dễ dàng cảm nhận được nhất khi sử dụng nước hoa này.\r\nHương đầu chủ yếu tập trung vào cam Mandarin, Đào, Dừa, Quả Lý Chua. Các nốt hương giữa là những cánh hoa hồng Pháp nhẹ nhàng, kế đến là hoa Nhài, Hoa Thủy Tiên. Các nốt hương cuối tăng phần gợi cảm và quyến rũ nhờ vào xạ hương trắng, hổ phách, vani và Benzoin.'),
(14, NULL, 1, NULL, 'Dior Sauvage Parfum', 'Dior-Sauvage-Parfum.png', 3750000, NULL, 'Dior', 'Dior Sauvage Parfum được nhiều người biết biết đến là phiên bản tiếp nối thành công vang dội của năm 2015 trước đó. Nước hoa Sauvage Eau de parfum năm 2019 này được tạo tác dựa trên ý tưởng mang đến cho nam giới một phong cách hương Nam tính, mạnh mẽ, lôi cuốn.\r\n\r\nNếu bạn đã từng thử qua phiên bản năm 2015, thì có lẽ sẽ rất ấn tượng với hương vị độc đáo mà nó được tạo thành.\r\n\r\nPhiên bản nước hoa Dior Sauvage Parfum vẫn tạo được sự thành công bởi việc vận dụng hương vị của bản gốc nhưng có phần tô điểm thêm một vài yếu tố khiến nó trở nên hoàn hảo hơn. Chính vì thế kể từ khi Dior ra mắt sản phẩm này rất được nhiều người đón tiếp và đưa ra phản hồi tích cực.\r\nNước hoa Dior Sauvage Parfum\r\nDưới góc nhìn của một người trải nghiệm thực tế hương vị của loại nước hoa này, có thể nói rằng sản phẩm vào năm 2018 này đạt được rất nhiều thành công từ hương vị cho đến thiết kế, với đại diện Johnny Depp đã phần nào tôn vinh được vị thế của nó kể từ khi ra mắt.\r\n\r\nDior Sauvage Parfum làm nổi bật các khía cạnh khác hẳn so với bản cũ mặc dù vẫn tận dụng các thành phần từ bản gốc trước đó. Mang một phương vị đậm chất Phương Đông, hương vị vani đầy ấm áp, gợi cảm và rất tinh tế.\r\n\r\nHương vị khác biệt\r\nDior Sauvage Eau de parfum mà Perfume168 mang đến có một hương vị rất hiện đại, ấm áp và gợi cảm nhằm tôn vinh lên vẻ đẹp của nam giới ở thế kỷ 21. Vận dụng thành công của năm 2015 vào 2018 nhưng có thể nói rằng phiên bản này thành công hơn hẳn.\r\n\r\nBởi vì kể từ khi ra mắt, nó đã được rất nhiều người đón tiếp và sử dụng rộng rãi và xem là hương vị của những người đàn ông lịch lãm với một trái tim yêu thương đầy ấm áp.\r\n\r\nDior Sauvage Eau de parfum khởi đầu với hương vị tươi mát và sảng khoái nhờ sự góp mặt của cam Bergamot đem lại một vị ngọt ngào đầy trang trọng. Lớp giữa là sự kết hợp khá tài tình của oải hương, tiêu Tứ Xuyên, đại hồi, hoa nhục đậu khấu khiến cho hương vị thêm phần ấm áp và nhẹ nhàng.\r\n\r\nKết thúc của Dior Sauvage Eau de parfum đến từ vanilla và nhựa ambroxan mang lại một hương thơm rất lịch lãm và sang trọng, đầy sức lôi cuốn.\r\n\r\nViệc kết hợp bố trí hương vị hài hòa này khiến cho nó trở nên rất tinh tế và hoàn hảo, tạo ra một bức tranh hương sắc vô cùng thú vị và độc đáo. Tô điểm thêm phần ấm áp, gợi cảm đầy nam tính khiến cho người sử dụng thể hiện được tình yêu của mình với đối phương rất mạnh mẽ hoặc cũng có thể thu hút mọi người xung quanh bằng hương thơm đầy huyền bí.');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanphamban`
--

CREATE TABLE `sanphamban` (
  `idsanphamban` int(11) NOT NULL,
  `tensanphamban` int(11) NOT NULL,
  `idsanpham` int(11) NOT NULL,
  `soluongban` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tinhtrang`
--

CREATE TABLE `tinhtrang` (
  `idtinhtrang` int(11) NOT NULL,
  `tentinhtrang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `tinhtrang`
--

INSERT INTO `tinhtrang` (`idtinhtrang`, `tentinhtrang`) VALUES
(1, 'Chờ lấy hàng'),
(2, 'Đang giao hàng'),
(3, 'Giao thành công'),
(4, 'Giao không thành công');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `tintuc`
--

CREATE TABLE `tintuc` (
  `idtintuc` int(11) NOT NULL,
  `tieudetin` text NOT NULL,
  `chitiettin` text NOT NULL,
  `hinhanh` varchar(255) NOT NULL,
  `solanxem` int(11) NOT NULL,
  `ngaydangtin` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `tintuc`
--

INSERT INTO `tintuc` (`idtintuc`, `tieudetin`, `chitiettin`, `hinhanh`, `solanxem`, `ngaydangtin`) VALUES
(1, '8 VỊ TRÍ XỊT NƯỚC HOA GIÚP GIỮ HƯƠNG LÂU NHẤT', 'Vị trí xịt nước hoa cho nam, nữ như thế nào là đúng cách để giữ hương thơm được lâu nhất luôn là vấn đề được nhiều người quan tâm, nhất là đối với những ai vừa mới tiếp xúc hoặc trước giờ chỉ áp dụng tùy ý theo sở thích của mình.\r\nVậy thì những vị trí xịt nước hoa cho nam, nữ nào là chuẩn nhất? trong bài viết này sẽ giải đáp chi tiết và rõ ràng câu hỏi này để bạn có thêm nguồn kiến thức hữu ích về việc sử dụng nước hoa này nhé.\r\n\r\n1. Xịt nước hoa lên tóc:\r\nĐối với nữ thì thường sở hữu cho mình những mái tóc bồng bềnh với vô số sợi tóc nhỏ được quyện vào nhau tạo ra nơi lý tưởng để giúp phát tán và lưu giữ mùi hương nước hoa hiệu quả nhất là dòng nước hoa dior mini. Đối với nam thì tuy mái tóc sẽ không lý tưởng như vậy nhưng cũng có thể áp dụng vào một số thời điểm mình mong muốn với một lượng ít hơn so với nữ.\r\nCách sử dụng với vị trí này là xịt đều nước hoa của bạn lên chiếc lược chải tóc, sau đó chải đều nhẹ nhàng. Lưu ý là nên tránh tình trạng xịt trực tiếp vào tóc, vì như vậy sẽ khiến tóc trở nên khô hơn.\r\n\r\n2. Xịt nước hoa sau tai\r\nĐây là vị trí thường được áp dụng và khuyến khích nên áp dụng nhất vì vị trí này sẽ tiếp nhận những giọt nước hoa thơm ngát để giúp bạn tự tin cả ngày. Bạn xịt nhẹ vào sau hai vành tai và nếu muốn hương thơm mau lan tỏa thì có thể dùng tay xoa xoa một chút.\r\n\r\n3. Dọc theo gáy xuống lưng\r\nGáy vốn dĩ luôn là một vị trí xịt nước hoa quá quen thuộc dành cho cả nam và nữ, nhưng có thể bạn chưa biết đến việc xịt một đường thẳng từ gáy xuống dưới dọc sống lưng với lượng nước hoa nhỏ thôi cũng có thể giúp bạn thơm ngát cả ngày rồi.\r\n\r\n4. Xịt nước hoa bên trong khuỷu tay\r\nĐây được xem như là một điểm “ phát nhiệt” nổi trội trên cơ thể của mỗi người vì khi bạn xịt nước hoa vào phần bên trong khuỷu tay thì mùi thơm của nó sẽ được tản đều ra xung quanh và được lưu lại rất lâu.\r\nĐiều khiến nơi này nổi bật khi xịt nước hoa đó là khi da bạn càng đủ nước thì mùi hương nước hoa sẽ càng giữ lại lâu hơn, chính vì vậy nên việc bạn dưỡng ẩm cho da cũng giúp ích rất nhiều trong việc giữ hương thơm ngát và lâu dài.\r\n\r\n5. Xịt nước hoa phần lưng\r\nPhần này nghe có vẻ hơi lạ lẫm đối với mọi người, tuy nhiên đây là vị trí được rất nhiều chuyên gia khuyến khích áp dụng để giữ hương được lâu hơn mà lại không tạo ra cảm giác nồng nặc.\r\n\r\n6. Xịt nước hoa vào rốn\r\nThường thì vị trí này sẽ không có nhiều người biết đến và áp dụng, tuy nhiên bạn chỉ cần sử dụng một giọt nước hoa lên điểm này thôi là cũng đã giúp bạn luôn có mùi hương dễ chịu bên mình suốt cả ngày.\r\n\r\n7. Xịt nước hoa trong khuỷu chân\r\nKhuỷu chân là nơi các tĩnh mạch nằm ở gần da nhất, vì thế nên khi bạn xịt nước hoa vào điểm này thì sẽ giúp mùi hương lan tỏa một cách nhanh chóng và hiệu quả. Đặc biệt là đối với những bạn nữ mặc váy ngắn trên gối.\r\n\r\n8. Xịt nước hoa trên mắt cá chân\r\nKhi bạn áp dụng cách này thì mùi hương sẽ được lan tỏa theo từng bước đi của bạn và bạn sẽ được tỏa hương lâu dài “ từ đầu đến chân” theo đúng với nghĩa đen của từ này. Đảm bảo hương thơm luôn tạo ra cảm giác nhẹ nhàng, phù hợp với cả nam và nữ.\r\n\r\n*Lưu ý: Đối với những vị trí được kể trên thì bạn chỉ cần sử dụng xịt lên từ 2-3 vùng là sẽ giúp bạn tỏa ngát hương rồi.', 'vi_tri_xit-nuoc-hoa.jpg', 100, '2020-11-12 00:00:00'),
(2, 'TOP NHỮNG LOẠI NƯỚC HOA RẺ MÀ CHẤT LƯỢNG', 'Trong vô vàn các dòng nước hoa đang được bán trên thị trường thì hầu như ai cũng đều muốn tìm hiểu về những loại nước hoa rẻ mà chất lượng nhằm mục đích tiết kiệm được phần nào đó chi phí cần thiết, nhưng vẫn đảm bảo đáp ứng được tiêu chuẩn về mùi hương mà mình đề ra. Thế nhưng việc này đối với những người mới tiếp xúc thì sẽ không dễ dàng tý nào cả.\r\n\r\nChính vì vậy mà trong bài viết này Perfume168 sẽ giới thiệu đến bạn những loại nước hoa rẻ mà chất lượng đang được nhiều người ưa chuộng. Điều này sẽ giúp bạn có cái nhìn tổng quan và dễ dàng lựa chọn được sản phẩm nước hoa phù hợp với bản thân mình hơn, hãy cùng xem qua nhé.\r\n\r\nNhững loại nước hoa rẻ mà chất lượng nào đang được ưa chuộng?\r\nSẽ có những loại nước hoa được kể tên như sau:\r\n\r\nNước hoa My Burberry for Women By Burberry Eau De Parfum Spray\r\nĐây là một trong những dòng sản phẩm có mùi hương nước hoa được đánh giá là quyến rũ nhất dễ khiến phái nam bị thu hút khi sử dụng. Đồng thời về ngữ cảnh thì bạn có thể sử dụng hầu như cho mọi nhịp như: công sở, dạo phố, dự tiệc…dù đi đến đâu thì bạn đều dễ dàng thể hiện cá tính của bản thân mình với mọi người.\r\nMy Burberry for Women được sử dụng với hương thơm hoa cỏ Phương Đông nổi tiếng trên toàn thế giới. Ưu điểm khi nhắc đến sản phẩm này đó là độ lưu hương lâu và không giảm đi lượng mùi khi tiếp xúc với hầu hết các khí hậu môi trường.\r\n\r\n \r\n\r\nSo với các dòng nước hoa trên thị trường thì mức giá của My Burberry for Women nằm ở phân khúc giá rẻ tầm trung để người dùng dễ lựa chọn. Chính vì vậy nên sản phẩm này được xem là một trong những loại nước hoa rẻ mà chất lượng hiện đang được bán trên thị trường hiện tại.\r\n\r\nNước hoa Versace Eros Pour Femme\r\nMùi hương của dòng sản phẩm Versace Eros khi nhắc đến đều mang lại cảm giác cuốn hút nhiều nhiều nhất cho các chị em phụ nữ. Hương thơm lâu kết hợp với những tầng hương nhẹ nhàng thay đổi theo từng thời điểm sẽ khiến người sử dụng và cả những người xung quanh đi từ bất ngờ này đến bất ngờ khác.\r\nSản phẩm này thích hợp dùng cả trong môi trường công sở và các buổi tiệc nho nhỏ. Giá thành của sản phẩm cũng khá rẻ và phù hợp với những ai muốn tạo ra phong cách riêng của bản thân mình.\r\n\r\nNước hoa Gucci Bamboo dành cho nữ\r\nNếu bạn là cô nàng thường xuyên đi tiệc tùng và đồng thời là tín đồ của thương hiệu Gucci thì đừng bỏ lỡ qua mùi hương đặc trưng của quả cam Bergamot thơm ngọt và dịu nhẹ này nhé. Sự kết hợp bởi những khung mùi đặc trưng khiến Gucci Bamboo trở nên thực sự cuốn hút hơn bao giờ hết và trong số đó ngoài quả cam Bergamot ra thì chúng ta có thể kể đến như: hoa ngọc lan tây, hương Casablanca và vị nồng cay từ hoa cam, gỗ hổ phách, đàn hương…\r\nVới tất cả những điều này thì khi sử dụng bạn sẽ cảm nhận được rằng mình giống như đang mang trong mình cả một vườn hoa đặc biệt đầy thơm ngát. Điều này sẽ giúp bạn trở nên tự tin hơn rất nhiều khi ra ngoài tiếp xúc với mọi người.', 'top_nuoc_hoa_re_chat_luong.jpg', 122, '2020-11-13 00:00:00'),
(3, '3 LỢI ÍCH TỪ NƯỚC HOA MINI VÀ CÁCH SỬ DỤNG HIỆU QUẢ', 'Những lợi ích và cách sử dụng nước hoa mini làm sao cho hiệu quả luôn là vấn đề thường được nhắc đến của những người đang tìm hiểu để lựa chọn. Một câu hỏi khá phổ biến được đặt ra đó là “ một chai nước hoa mini dung tích nhỏ làm được gì với phiên bản có dung tích lớn hơn và được dùng lâu hơn? ”.\r\n\r\nNếu bạn đang có suy nghĩ như vậy thì những thông tin được perfume168 chia sẻ dưới đây sẽ giải đáp được câu hỏi này và đồng thời giúp bạn biết được cách sử dụng nước hoa mini như thế nào là hiệu quả nhất nhé.\r\nLợi ích khi sử dụng nước hoa mini là gì?\r\nLợi ích đến từ lọ nước hoa mini khá nhiều, tuy nhiên sẽ có 3 lợi ích thiết thực nhất được nhắc đến sau đây:\r\n\r\n1. Phù hợp với các loại túi xách, ví cầm tay\r\nĐối với bất kỳ cô gái nào cũng vậy, túi xách và ví cầm tay hầu như là một phụ kiện thời trang không thể nào thiếu được. Ngoài việc hỗ trợ cất giữ những món đồ cần thiết trong đó có nước hoa cho cả ngày hoạt động, làm việc thì nó còn giúp ích rất nhiều trong việc giúp nổi bật phong cách của người sử dụng nữa.\r\n\r\nCó một sự thật là hầu như không bạn gái nào muốn mang một lọ nước hoa với dung tích 100ml to đùng và bỏ vào chiếc túi xách bé nhỏ của mình cả. Điều này sẽ chiếm một phần lớn diện tích bên trong và hiển nhiên là sẽ không đủ để bỏ thêm một số vật dụng cần thiết khi ra ngoài rồi.\r\n\r\nViệc lựa chọn một lọ nước hoa mini với dung tích nhỏ sẽ không chiếm quá nhiều khoảng trống bên trong khi cho vào mà lại dễ dàng lấy ra sử dụng. Điều này sẽ khiến bạn cảm thấy dễ chịu hơn rất nhiều.\r\n2. Loại “trang sức” không thể thiếu khi đi du lịch\r\nVới những chuyến du lịch ngắn ngày thì việc sử dụng một lọ nước hoa mini sẽ giúp bạn tiết kiệm nhiều khoảng trống so với để một số loại sản phẩm làm thơm to lớn khác, vì vậy nên bạn có thể mang nhiều món đồ cần thiết hơn dành cho mình.\r\n\r\nMột điểm lợi nữa đó là những lọ nước hoa mini thường có thể biến đổi theo nhiều hương thơm khác nhau tạo sự mới mẻ chứ không như một loại hương thơm mà mình sử dụng quá quen thuộc hàng ngày rồi.\r\n\r\n3. Nước hoa mini giúp tiết kiệm\r\nĐây là một trong những lợi ích thiết thực nhất mà các dòng nước hoa mini mang lại cho người sử dụng. Hầu như giá thành của các loại này thường không cao vì lượng dung tích nhỏ, người dùng có thể tiết kiệm được một khoản kha khá nhưng vẫn đảm bảo được đầy đủ yếu tố cần thiết khi sử dụng.\r\nCách sử dụng nước hoa mini như thế nào để hiệu quả?\r\nCách sử dụng nước hoa mini thì cũng sẽ không khác gì mấy so với sử dụng thông thường, và bạn cần để ý đặc biệt đến những điểm sau đây:\r\n\r\n– Vì nước hoa mini có dung tích nhỏ nên khi sử dụng bạn cần chú ý đến liều lượng khi xịt. Cách tốt nhất đó là nên để cách tay tầm khoảng 5cm và bấm xịt nhẹ nhàng vào vị trí mình muốn xịt.\r\n\r\n– Chọn điểm xịt phù hợp cũng sẽ giúp bạn tiết kiệm lượng nước hoa trong khi sử dụng. Những điểm khuyến khích bạn sử dụng đó là cổ tay, gáy, sau tai, ngực, đầu gối…\r\n– Cuối cùng thì để sử dụng đúng cách nước hoa mini thì bạn nên chú ý làm ẩm làn da của mình trước khi dùng để lưu giữ mùi hương nước hoa được lâu hơn. Tốt nhất là nên dùng kem dưỡng ẩm có mùi tương tự nước hoa.\r\n\r\nNhững thông tin được sangperfume kể trên đó là một số lợi ích thiết thực từ lọ nước hoa mini và cách sử dụng làm sao để hiệu quả nhất. Bạn sẽ không còn phải đắn đo khi đang thắc mắc về vấn đề không biết mình có phù hợp để sử dụng hay không hoặc là công dụng của sản phẩm này mang lại.', 'loi_ich_nuoc-hoa-mini.jpg', 130, '2020-11-14 00:00:00');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  ADD PRIMARY KEY (`idbinhluan`),
  ADD KEY `idsanpham` (`idsanpham`);

--
-- Chỉ mục cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  ADD PRIMARY KEY (`iddanhmuc`);

--
-- Chỉ mục cho bảng `giohang`
--
ALTER TABLE `giohang`
  ADD PRIMARY KEY (`idgiohang`),
  ADD KEY `idhoadon` (`idhoadon`);

--
-- Chỉ mục cho bảng `hoadon`
--
ALTER TABLE `hoadon`
  ADD PRIMARY KEY (`idhoadon`),
  ADD KEY `idkhachhang` (`idkhachhang`),
  ADD KEY `idtinhtrang` (`idtinhtrang`);

--
-- Chỉ mục cho bảng `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`idkhachhang`),
  ADD UNIQUE KEY `tendangnhap` (`taikhoan`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`idsanpham`),
  ADD KEY `iddanhmuc` (`iddanhmuc`),
  ADD KEY `idkhuyenmai` (`idkhuyenmai`),
  ADD KEY `idgiohang` (`idhoadon`);

--
-- Chỉ mục cho bảng `sanphamban`
--
ALTER TABLE `sanphamban`
  ADD PRIMARY KEY (`idsanphamban`),
  ADD KEY `idsanpham` (`idsanpham`);

--
-- Chỉ mục cho bảng `tinhtrang`
--
ALTER TABLE `tinhtrang`
  ADD PRIMARY KEY (`idtinhtrang`);

--
-- Chỉ mục cho bảng `tintuc`
--
ALTER TABLE `tintuc`
  ADD PRIMARY KEY (`idtintuc`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  MODIFY `idbinhluan` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT cho bảng `danhmuc`
--
ALTER TABLE `danhmuc`
  MODIFY `iddanhmuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT cho bảng `giohang`
--
ALTER TABLE `giohang`
  MODIFY `idgiohang` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT cho bảng `hoadon`
--
ALTER TABLE `hoadon`
  MODIFY `idhoadon` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT cho bảng `khachhang`
--
ALTER TABLE `khachhang`
  MODIFY `idkhachhang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `idsanpham` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT cho bảng `sanphamban`
--
ALTER TABLE `sanphamban`
  MODIFY `idsanphamban` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT cho bảng `tinhtrang`
--
ALTER TABLE `tinhtrang`
  MODIFY `idtinhtrang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT cho bảng `tintuc`
--
ALTER TABLE `tintuc`
  MODIFY `idtintuc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `binhluan`
--
ALTER TABLE `binhluan`
  ADD CONSTRAINT `gk_bl_sp1` FOREIGN KEY (`idsanpham`) REFERENCES `sanpham` (`idsanpham`);

--
-- Các ràng buộc cho bảng `hoadon`
--
ALTER TABLE `hoadon`
  ADD CONSTRAINT `fk_hd_kh` FOREIGN KEY (`idkhachhang`) REFERENCES `khachhang` (`idkhachhang`),
  ADD CONSTRAINT `fk_hd_tt` FOREIGN KEY (`idtinhtrang`) REFERENCES `tinhtrang` (`idtinhtrang`);

--
-- Các ràng buộc cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `fk_dm_sp` FOREIGN KEY (`iddanhmuc`) REFERENCES `danhmuc` (`iddanhmuc`),
  ADD CONSTRAINT `fk_hd_sp` FOREIGN KEY (`idhoadon`) REFERENCES `hoadon` (`idhoadon`);

--
-- Các ràng buộc cho bảng `sanphamban`
--
ALTER TABLE `sanphamban`
  ADD CONSTRAINT `fk_spb_sp` FOREIGN KEY (`idsanpham`) REFERENCES `sanpham` (`idsanpham`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
