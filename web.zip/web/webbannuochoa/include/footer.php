<div class="footer">
		<div class="container">
				<div class="footer-class">
				<div class="class-footer">
					<ul>
						<li ><a href="index.php" class="scroll">Trang Chủ </a><label>|</label></li>
						<li><a href="nuochoanam.php" class="scroll">Nước hoa Nam</a><label>|</label></li>
						<li><a href="nuochoanu.php" class="scroll">Nước hoa nữ</a><label>|</label></li>
						<li><a href="nuochoaunisex.php" class="scroll">Nước hoa Unisex</a><label>|</label></li>
						<li><a href="sale-off.php" class="scroll">Khuyến Mãi</a><label>|</label></li>
						<li><a href="baohanh.php" class="scroll">Bảo Hành</a></li>
					</ul>
					 <p class="footer-grid">&copy; 2020</p>
				</div>	 
				<div class="footer-left">
					<a href="index.php"><img src="images/logo1.png" alt=" " ></a>
				</div> 
				<div class="clearfix"> </div>
			 	</div>
		 </div>
	</div>