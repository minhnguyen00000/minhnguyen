<div class="col-md-9 col-d">
			<div class="in-line">
				<div class="para-an" >
						<h3>KẾT QUẢ TÌM KIẾM</h3>
				</div>
				<div class="lady-in">
                    <?php 
                        include('include/connect.php');
                        if (isset($_POST['search'])) 
                        {
							$data = $_POST['search'];
                            $query = "SELECT * FROM sanpham WHERE tensanpham like '%$data%'";
                            $stm = $obj->prepare($query);
                            $stm->execute();
							$datab = $stm->fetchAll(); 
							if (!$datab) 
							{
                             	echo ("Không tìm thấy kết quả !!!");
                            }
                        } 
						foreach ($datab as $v)
						{
						?>
						<div class="col-md-4 you-para"  >
							<table>
							<a href="chitiet.php?idsanpham=<?php echo $v['idsanpham']?>"><img class="img-responsive pic-in" src="images/<?php echo($v['anhsanpham']) ?>" alt=" " ></a>
							<p><?php echo $v['tensanpham']  ?></p>
							<span><?php echo number_format($v['giasanpham'])?><label class="cat-in"> </label> <a href="chitiet.php?idsanpham=<?php echo $v['idsanpham']?>">Xem sản phẩm </a></span>
						</table>
						</div>
						<?php
						}
					?> 
						<div class="clearfix"> </div>
				</div>
			</div>
</div>